import json
import sys
import os
from collections import defaultdict
import torch
from transformers import AutoModel, AutoTokenizer
from sklearn.cluster import KMeans
import numpy as np
import json
import torch.nn as nn
import torch.nn.functional as F
from sklearn.metrics import classification_report
sys.path.append(os.path.join('../pstal-etu/lib/'))
from conllulib import CoNLLUReader
from torch.utils.data import DataLoader
from umap import UMAP
from sklearn.preprocessing import LabelEncoder
import seaborn as sns 
from sklearn.neighbors import KNeighborsClassifier
import matplotlib.pyplot as plt
import random
from sklearn.decomposition import PCA
from matplotlib import pyplot as plt
path = '.'


# Chargement des modèles et données
model = AutoModel.from_pretrained('almanach/camembert-base')
tokenizer = AutoTokenizer.from_pretrained('almanach/camembert-base')
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model.to(device)
k=2
with open("embeddings_cam.json", "r") as file:
    train_data = json.load(file)
with open("mapping_cam.json", "r") as file:
    mapping = json.load(file)
path = '.'
# Fonction de chargement des données de test
def dataloader_test(file):
    test_data = []
    with open(file, 'r') as f:
        reader = CoNLLUReader(f)
        for sent in reader.readConllu():
            mots = [tok["form"] for tok in sent]
            labels = [tok.get("frsemcor:noun", "") for tok in sent]
            token_obj = tokenizer(mots, is_split_into_words=True, return_tensors='pt').to(device)
            word_ids = token_obj.word_ids()
            
            with torch.no_grad():
                embeddings = model(**token_obj)["last_hidden_state"].to(device)
            
            for word_idx in range(len(mots)):
                token_indices = [i for i, w_id in enumerate(word_ids) if w_id == word_idx]
                if token_indices:
                    avg_embedding = embeddings[:, token_indices, :].mean(dim=1).squeeze(0).cpu().numpy()
                    test_data.append({
                        "word": mots[word_idx],
                        "embedding": avg_embedding.tolist(),
                        "label": mapping.get(labels[word_idx], -1)
                    })
    return test_data


file_test = os.path.join(path, '../pstal-etu/sequoia/sequoia-ud.parseme.frsemcor.simple.test')
test_data = dataloader_test(file_test)
k=2


accuracies_cam = []



for _ in range(5):
    
    subset_size = int(len(train_data))
    subset_train = random.sample(train_data, subset_size)
    
    train_embeddings = [np.array(item["embedding"]) for item in subset_train]
    train_labels = [item["class"] for item in subset_train]
    

    knn = KNeighborsClassifier(n_neighbors=k)  
    knn.fit(train_embeddings, train_labels)
    
    true_labels = []
    predicted_labels = []
    for item in test_data:
        embedding = np.array(item["embedding"])
        true_label = item["label"]
        if true_label != 1:  # ignorer les '*'
            predicted_label = knn.predict([embedding])[0]
            true_labels.append(true_label)
            predicted_labels.append(predicted_label)
    

    accuracy = np.mean(np.array(true_labels) == np.array(predicted_labels))
    accuracies_cam.append((accuracy))


tokenizer = AutoTokenizer.from_pretrained('bert-base-uncased') # ('almanach/camembert-base')
model = AutoModel.from_pretrained('bert-base-uncased')
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model.to(device)
k=2
with open("embeddings_goo.json", "r") as file:
    train_data = json.load(file)
with open("mapping_goo.json", "r") as file:
    mapping = json.load(file)
path = '.'

accuracies_goo= []


for _ in range(5):
    
    subset_size = int(len(train_data))
    subset_train = random.sample(train_data, subset_size)
    
    train_embeddings = [np.array(item["embedding"]) for item in subset_train]
    train_labels = [item["class"] for item in subset_train]
    

    knn = KNeighborsClassifier(n_neighbors=k)  
    knn.fit(train_embeddings, train_labels)
    
    true_labels = []
    predicted_labels = []
    for item in test_data:
        embedding = np.array(item["embedding"])
        true_label = item["label"]
        if true_label != 1:  # ignorer les '*'
            predicted_label = knn.predict([embedding])[0]
            true_labels.append(true_label)
            predicted_labels.append(predicted_label)
    

    accuracy = np.mean(np.array(true_labels) == np.array(predicted_labels))
    accuracies_goo.append((accuracy))


# plt.scatter(np.array([e[0] for e in accuracies]) * 100, [e[1] for e in accuracies], marker='o', label="Accuracy")
# plt.title("Accuracy en fonction de la proportion des données d'entraînement (k-NN)")
# plt.xlabel("Proportion des données d'entraînement (% du dataset d'entraînement)")
# plt.ylabel("Accuracy")
# plt.legend()
# plt.grid()
# plt.show()


# proportions = np.array([e[0] for e in accuracies]) * 100
# accuracy_values = [e[1] for e in accuracies]

# unique_proportions = sorted(set(proportions))
# grouped_accuracies = [
#     [accuracy_values[i] for i in range(len(proportions)) if proportions[i] == p]
#     for p in unique_proportions
# ]
# plt.boxplot(grouped_accuracies, labels=[f"{p:.0f}%" for p in unique_proportions])
# plt.title(f"Accuracy en fonction de la proportion des données d'entraînement ({k}-NN)")
# plt.xlabel("Proportion des données d'entraînement (% du dataset d'entraînement)")
# plt.ylabel("Accuracy")
# plt.grid(axis='y')
# plt.show()
    

# Précisions obtenues pour Camembert et BERT
# accuracies_cam_mean = np.mean(accuracies_cam)
# accuracies_goo_mean = np.mean(accuracies_goo)

# Labels des modèles
models = ['Camembert','Camembert','Camembert','Camembert','Camembert', 'BERT','BERT','BERT','BERT','BERT']

# Valeurs de précisions moyennes
# accuracies = [accuracies_cam_mean, accuracies_goo_mean]

# Création du graphique
plt.figure(figsize=(8, 6))
plt.scatter(models, accuracies_cam + accuracies_goo)

# Ajout des labels et titre
# plt.ylabel('Précision Moyenne')
plt.title('Comparaison des Précisions entre Camembert et BERT')
# plt.ylim(0, 1)  # Plage des précisions de 0 à 1
# plt.grid(True, linestyle='--', alpha=0.6)

# Affichage des précisions sur les barres
# for i, v in enumerate(accuracies):
#     plt.text(i, v + 0.02, f'{v:.2f}', ha='center', va='bottom', fontsize=12)

# Afficher le graphique
plt.show()